<?php
$pdo = new PDO("mysql:host=localhost;dbname=forum_db;charset=utf8", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>