<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $user_id = $_SESSION['user']['id'];

    $stmt = $pdo->prepare("INSERT INTO posts (user_id, title, content) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $title, $content]);

    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Создать пост</title>
</head>
<body>
    <h2>Создать пост</h2>
    <form method="POST">
        Заголовок: <input type="text" name="title" required><br>
        Содержание:<br>
        <textarea name="content" rows="5" required></textarea><br>
        <button>Опубликовать</button>
    </form>
    <a href="index.php">Назад</a>
</body>
</html>