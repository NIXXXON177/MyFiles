<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->query("SELECT p.*, u.username FROM posts p JOIN users u ON p.user_id = u.id ORDER BY p.created_at DESC");
$posts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Форум</title>
</head>
<body>
    <h1>Форум</h1>
    <p>Привет, <?= htmlspecialchars($_SESSION['user']['username']) ?>! 
        <a href="profile.php">Личный кабинет</a> | 
        <a href="logout.php">Выход</a>
    </p>

    <?php if ($_SESSION['user']['is_admin']): ?>
        <p><a href="admin.php">🛠️ Админ-панель</a></p>
    <?php endif; ?>

    <h2><a href="create_post.php">➕ Создать пост</a></h2>

    <?php foreach ($posts as $post): ?>
        <div style="border: 1px solid #ccc; margin: 10px; padding: 10px;">
            <h3><?= htmlspecialchars($post['title']) ?></h3>
            <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
            <p><small>Автор: <?= htmlspecialchars($post['username']) ?> | 
                <?= $post['created_at'] ?>
                <?php if ($_SESSION['user']['id'] == $post['user_id'] || $_SESSION['user']['is_admin']): ?>
                    | <a href="delete_post.php?id=<?= $post['id'] ?>" onclick="return confirm('Удалить?')">🗑️ Удалить</a>
                <?php endif; ?>
            </small></p>
        </div>
    <?php endforeach; ?>
</body>
</html>