import {Auth} from './Auth';
export default Auth;