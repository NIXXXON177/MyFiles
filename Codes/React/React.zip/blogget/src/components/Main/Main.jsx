import React from 'react';
import Layout from '../Layout';

export const Main = () => {
  return (
    <main>
      <Layout>
      </Layout>
    </main>
  )
}