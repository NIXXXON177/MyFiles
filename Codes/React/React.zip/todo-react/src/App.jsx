const App = () => {
  return (
    <div>
      <h1>To Do list</h1>
    </div>
  )
}
export default App;