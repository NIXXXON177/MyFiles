<h2>Laralove</h2>
<?php /**PATH C:\Users\NIXXXON\Desktop\MyFiles\Codes\Laravel\laravel9\resources\views/test.blade.php ENDPATH**/ ?>