<h1>Привет, Ларавел</h1>
<?php /**PATH C:\Users\NIXXXON\Desktop\MyFiles\Codes\Laravel\laravel9\resources\views/welcome.blade.php ENDPATH**/ ?>